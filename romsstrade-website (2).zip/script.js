// Import Firebase v9+ modules
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.22.0/firebase-app.js"
import { getAnalytics } from "https://www.gstatic.com/firebasejs/9.22.0/firebase-analytics.js"
import {
  getAuth,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  sendEmailVerification,
  onAuthStateChanged,
} from "https://www.gstatic.com/firebasejs/9.22.0/firebase-auth.js"

// Firebase Configuration - Updated with correct config
const firebaseConfig = {
  apiKey: "AIzaSyCgNnID2loaKWwIZLimgdLyE00O1lbblzk",
  authDomain: "romsstrade.firebaseapp.com",
  projectId: "romsstrade",
  storageBucket: "romsstrade.appspot.com", // ✅ Fixed
  messagingSenderId: "99931216193",
  appId: "1:99931216193:web:42b2899fb9065ae11129c0", // ✅ Updated
  measurementId: "G-DD7B30ZKRC", // ✅ Added
}

// Initialize Firebase
const firebaseApp = initializeApp(firebaseConfig)
const analytics = getAnalytics(firebaseApp)
const auth = getAuth(firebaseApp)

// Show/Hide loading overlay
function showLoading() {
  document.getElementById("loadingOverlay").classList.remove("hidden")
}

function hideLoading() {
  document.getElementById("loadingOverlay").classList.add("hidden")
}

// Show status message with styling
function showStatus(message, type = "info") {
  const statusElement = document.getElementById("status")
  statusElement.innerHTML = message

  // Remove existing classes
  statusElement.className = "text-center text-sm font-medium min-h-[20px]"

  // Add type-specific styling
  switch (type) {
    case "success":
      statusElement.classList.add("text-green-400")
      break
    case "error":
      statusElement.classList.add("text-red-400")
      break
    case "warning":
      statusElement.classList.add("text-yellow-400")
      break
    default:
      statusElement.classList.add("text-blue-400")
  }
}

// Register function
function register() {
  const email = document.getElementById("email").value
  const password = document.getElementById("password").value

  if (!email || !password) {
    showStatus("❌ Email dan password harus diisi!", "error")
    return
  }

  if (password.length < 6) {
    showStatus("❌ Password minimal 6 karakter!", "error")
    return
  }

  showLoading()
  showStatus("📝 Mendaftarkan admin baru...", "info")

  createUserWithEmailAndPassword(auth, email, password)
    .then((userCredential) => {
      // Send email verification
      sendEmailVerification(userCredential.user)
        .then(() => {
          hideLoading()
          showStatus(
            `
                        <div class="bg-green-900/30 border border-green-500 rounded-lg p-3 mt-2">
                            <i class="fas fa-envelope-circle-check text-green-400 mr-2"></i>
                            <strong>Registrasi Berhasil!</strong><br>
                            <small>Email verifikasi telah dikirim ke ${email}<br>
                            Silakan cek inbox dan klik link verifikasi.</small>
                        </div>
                    `,
            "success",
          )
        })
        .catch((error) => {
          hideLoading()
          showStatus("❌ Gagal mengirim email verifikasi: " + error.message, "error")
        })
    })
    .catch((error) => {
      hideLoading()
      let errorMessage = "❌ "

      switch (error.code) {
        case "auth/email-already-in-use":
          errorMessage += "Email sudah terdaftar!"
          break
        case "auth/invalid-email":
          errorMessage += "Format email tidak valid!"
          break
        case "auth/weak-password":
          errorMessage += "Password terlalu lemah!"
          break
        default:
          errorMessage += error.message
      }

      showStatus(errorMessage, "error")
    })
}

// Login function
function login() {
  const email = document.getElementById("email").value
  const password = document.getElementById("password").value

  if (!email || !password) {
    showStatus("❌ Email dan password harus diisi!", "error")
    return
  }

  showLoading()
  showStatus("🔐 Memverifikasi kredensial...", "info")

  signInWithEmailAndPassword(auth, email, password)
    .then((userCredential) => {
      if (userCredential.user.emailVerified) {
        showStatus("✅ Login berhasil! Mengalihkan ke dashboard...", "success")

        // Redirect to dashboard after short delay
        setTimeout(() => {
          window.location.href = "dashboard.html"
        }, 1500)
      } else {
        hideLoading()
        showStatus(
          `
                    <div class="bg-yellow-900/30 border border-yellow-500 rounded-lg p-3 mt-2">
                        <i class="fas fa-exclamation-triangle text-yellow-400 mr-2"></i>
                        <strong>Email Belum Terverifikasi!</strong><br>
                        <small>Silakan cek inbox email Anda dan klik link verifikasi.<br>
                        Atau klik tombol "Kirim Ulang Email Verifikasi" di bawah.</small>
                    </div>
                `,
          "warning",
        )
      }
    })
    .catch((error) => {
      hideLoading()
      let errorMessage = "❌ "

      switch (error.code) {
        case "auth/user-not-found":
          errorMessage += "Email tidak terdaftar!"
          break
        case "auth/wrong-password":
          errorMessage += "Password salah!"
          break
        case "auth/invalid-email":
          errorMessage += "Format email tidak valid!"
          break
        case "auth/too-many-requests":
          errorMessage += "Terlalu banyak percobaan login. Coba lagi nanti."
          break
        default:
          errorMessage += error.message
      }

      showStatus(errorMessage, "error")
    })
}

// Resend verification email
function resendVerification() {
  const email = document.getElementById("email").value

  if (!email) {
    showStatus("❌ Masukkan email terlebih dahulu!", "error")
    return
  }

  // Check if user exists and is logged in
  const user = auth.currentUser

  if (user && !user.emailVerified) {
    showLoading()
    showStatus("📧 Mengirim ulang email verifikasi...", "info")

    sendEmailVerification(user)
      .then(() => {
        hideLoading()
        showStatus(
          `
                    <div class="bg-blue-900/30 border border-blue-500 rounded-lg p-3 mt-2">
                        <i class="fas fa-paper-plane text-blue-400 mr-2"></i>
                        <strong>Email Verifikasi Dikirim!</strong><br>
                        <small>Silakan cek inbox email ${user.email}</small>
                    </div>
                `,
          "success",
        )
      })
      .catch((error) => {
        hideLoading()
        showStatus("❌ Gagal mengirim email: " + error.message, "error")
      })
  } else {
    // Try to sign in first to get user object
    const password = document.getElementById("password").value

    if (!password) {
      showStatus("❌ Masukkan email dan password untuk mengirim ulang verifikasi!", "error")
      return
    }

    showLoading()

    signInWithEmailAndPassword(auth, email, password)
      .then((userCredential) => {
        if (!userCredential.user.emailVerified) {
          return sendEmailVerification(userCredential.user)
        } else {
          throw new Error("Email sudah terverifikasi!")
        }
      })
      .then(() => {
        hideLoading()
        showStatus(
          `
                    <div class="bg-blue-900/30 border border-blue-500 rounded-lg p-3 mt-2">
                        <i class="fas fa-paper-plane text-blue-400 mr-2"></i>
                        <strong>Email Verifikasi Dikirim!</strong><br>
                        <small>Silakan cek inbox email ${email}</small>
                    </div>
                `,
          "success",
        )
      })
      .catch((error) => {
        hideLoading()
        if (error.message === "Email sudah terverifikasi!") {
          showStatus("✅ Email sudah terverifikasi! Silakan login.", "success")
        } else {
          showStatus("❌ " + error.message, "error")
        }
      })
  }
}

// Auto-fill demo credentials (for testing)
function fillDemoCredentials() {
  document.getElementById("email").value = "admin@romsstrade.com"
  document.getElementById("password").value = "admin123"
}

// Add Enter key support
document.addEventListener("DOMContentLoaded", () => {
  const emailInput = document.getElementById("email")
  const passwordInput = document.getElementById("password")
  ;[emailInput, passwordInput].forEach((input) => {
    input.addEventListener("keypress", (e) => {
      if (e.key === "Enter") {
        login()
      }
    })
  })
})

// Check auth state on page load
onAuthStateChanged(auth, (user) => {
  if (user && user.emailVerified) {
    // User is signed in and verified, redirect to dashboard
    if (window.location.pathname.includes("index.html") || window.location.pathname === "/") {
      window.location.href = "dashboard.html"
    }
  }
})
