// ✅ Centralized Firebase Configuration
// Use this file to import consistent config across all pages

import { initializeApp } from "firebase/app"
import { getAuth } from "firebase/auth"
import { getAnalytics } from "firebase/analytics"
import { getFirestore } from "firebase/firestore"

// ✅ Final Firebase Configuration
const firebaseConfig = {
  apiKey: "AIzaSyCgNnID2loaKWwIZLimgdLyE00O1lbblzk",
  authDomain: "romsstrade.firebaseapp.com",
  projectId: "romsstrade",
  storageBucket: "romsstrade.appspot.com", // ✅ Fixed
  messagingSenderId: "99931216193",
  appId: "1:99931216193:web:42b2899fb9065ae11129c0", // ✅ Updated with correct appId
  measurementId: "G-DD7B30ZKRC", // ✅ Added Analytics
}

// Initialize Firebase
const app = initializeApp(firebaseConfig)

// Initialize services
export const auth = getAuth(app)
export const analytics = getAnalytics(app)
export const db = getFirestore(app)

export default app
