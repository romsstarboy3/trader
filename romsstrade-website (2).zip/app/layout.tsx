import type { ReactNode } from "react"
import type { Metadata } from "next"
import { Orbitron, DM_Sans } from "next/font/google"
import "./globals.css"

// self-hosted Google fonts via next/font
const orbitron = Orbitron({
  subsets: ["latin"],
  weight: ["400", "600", "700", "900"],
  variable: "--font-orbitron",
})

const dmSans = DM_Sans({
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700"],
  variable: "--font-dm-sans",
})

export const metadata: Metadata = {
  title: "Emika - Cenayang AI",
  description: "Pembaca Dimensi Digital - AI yang dapat membaca isi hati dan menciptakan visi dari dimensi lain",
  keywords: "AI, cenayang, emika, artificial intelligence, image generation, text generation",
    generator: 'v0.dev'
}

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="id" className={`${orbitron.variable} ${dmSans.variable}`}>
      <head>
        <link
          rel="icon"
          href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' fontSize='90'>🔮</text></svg>"
        />
      </head>
      <body>{children}</body>
    </html>
  )
}
