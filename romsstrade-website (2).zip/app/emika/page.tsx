"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft } from "lucide-react"
import RomssTradeLogo from "../../components/logo"

export default function EmikaAI() {
  const [userInput, setUserInput] = useState("")
  const [aiText, setAiText] = useState("")
  const [aiImages, setAiImages] = useState<string[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [isTyping, setIsTyping] = useState(false)
  const [showMusic, setShowMusic] = useState(false)

  // Typing animation effect
  const typeText = (text: string) => {
    setIsTyping(true)
    setAiText("")
    let i = 0

    const typeInterval = setInterval(() => {
      if (i < text.length) {
        setAiText((prev) => prev + text.charAt(i))
        i++
      } else {
        clearInterval(typeInterval)
        setIsTyping(false)
      }
    }, 30)
  }

  const runAI = async () => {
    if (!userInput.trim()) {
      alert("Tulis dulu sesuatu dong... 💭")
      return
    }

    setIsLoading(true)
    setAiText("")
    setAiImages([])
    setShowMusic(false)

    try {
      // Fetch AI text response
      const textResponse = await fetch(`https://berak.vercel.app/ai/viooai?text=${encodeURIComponent(userInput)}`)
      const textData = await textResponse.json()

      const aiMessage = textData.result || "Aku gak bisa baca dimensi trading itu... 📈"
      typeText(aiMessage)

      // Show music after text loads
      setTimeout(() => setShowMusic(true), 1000)
    } catch (error) {
      console.error("Error:", error)
      setAiText("Koneksi ke server trading terputus... 💫")
    } finally {
      setIsLoading(false)
    }
  }

  // Handle Enter key
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      runAI()
    }
  }

  return (
    <div className="min-h-screen bg-gray-800 text-white relative overflow-hidden">
      {/* Background Pattern - sama seperti romsstrade theme */}
      <div className="absolute inset-0 bg-gradient-to-br from-gray-800 via-gray-900 to-black opacity-90"></div>
      <div className="absolute inset-0 bg-gradient-to-tr from-yellow-500/5 via-transparent to-yellow-500/5"></div>

      {/* Animated Background */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-yellow-500 rounded-full mix-blend-multiply filter blur-xl animate-blob"></div>
        <div className="absolute top-1/3 right-1/4 w-96 h-96 bg-purple-500 rounded-full mix-blend-multiply filter blur-xl animate-blob animation-delay-2000"></div>
        <div className="absolute bottom-1/4 left-1/3 w-96 h-96 bg-blue-500 rounded-full mix-blend-multiply filter blur-xl animate-blob animation-delay-4000"></div>
      </div>

      {/* Floating Particles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(15)].map((_, i) => (
          <div
            key={i}
            className="absolute w-2 h-2 bg-yellow-400 rounded-full opacity-30 animate-float"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 5}s`,
              animationDuration: `${3 + Math.random() * 4}s`,
            }}
          />
        ))}
      </div>

      <div className="relative z-10 flex flex-col items-center justify-start min-h-screen p-4">
        {/* Header dengan branding romsstrade */}
        <div className="w-full max-w-6xl flex items-center justify-between mb-8 pt-4">
          <Link
            href="/"
            className="inline-flex items-center gap-2 text-yellow-500 hover:text-yellow-400 transition-colors"
          >
            <ArrowLeft size={20} />
            <span>Kembali ke Romsstrade</span>
          </Link>
          <RomssTradeLogo />
        </div>

        {/* Header Emika dengan branding romsstrade */}
        <div className="text-center mt-4 mb-12">
          <div className="flex items-center justify-center gap-4 mb-6">
            <div className="text-yellow-500 text-4xl">🔮</div>
            <h1 className="font-orbitron text-4xl md:text-6xl font-bold bg-gradient-to-r from-yellow-400 via-yellow-500 to-yellow-600 bg-clip-text text-transparent animate-glow">
              Emika AI
            </h1>
            <div className="text-yellow-500 text-4xl">📈</div>
          </div>
          <p className="text-xl text-gray-300 font-light tracking-wide mb-2">
            Cenayang Trading AI — Pembaca Sinyal Market
          </p>
          <p className="text-sm text-yellow-500 font-semibold">Powered by Romsstrade • Advanced Trading Intelligence</p>
          <div className="w-32 h-1 bg-gradient-to-r from-yellow-500 to-yellow-600 mx-auto mt-4 rounded-full"></div>
        </div>

        {/* Input Section */}
        <div className="w-full max-w-2xl mb-8">
          <div className="relative">
            <input
              type="text"
              value={userInput}
              onChange={(e) => setUserInput(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Tanya tentang trading... (contoh: analisa EURUSD hari ini)"
              className="w-full px-6 py-4 bg-gray-900/50 backdrop-blur-sm border border-yellow-500/30 rounded-2xl text-white placeholder-gray-400 focus:outline-none focus:border-yellow-500 focus:ring-2 focus:ring-yellow-500/20 transition-all duration-300"
              disabled={isLoading}
            />
            <div className="absolute inset-0 bg-gradient-to-r from-yellow-500/10 to-yellow-600/10 rounded-2xl pointer-events-none opacity-0 hover:opacity-100 transition-opacity duration-300"></div>
          </div>

          <button
            onClick={runAI}
            disabled={isLoading}
            className="w-full mt-4 px-8 py-4 bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 rounded-2xl font-semibold text-black transition-all duration-300 transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100"
          >
            {isLoading ? (
              <div className="flex items-center justify-center gap-3">
                <div className="w-5 h-5 border-2 border-black/30 border-t-black rounded-full animate-spin"></div>
                Menganalisa Market...
              </div>
            ) : (
              "🔮 Baca Sinyal Trading"
            )}
          </button>
        </div>

        {/* Results Section */}
        <div className="w-full max-w-4xl">
          {/* AI Text Response */}
          {aiText && (
            <div className="mb-8 p-6 bg-gray-900/50 backdrop-blur-sm border border-yellow-500/20 rounded-2xl">
              <h3 className="text-yellow-400 font-semibold mb-4 flex items-center gap-2">
                <span className="w-2 h-2 bg-yellow-400 rounded-full animate-pulse"></span>
                Emika Trading AI:
              </h3>
              <p className={`text-lg leading-relaxed ${isTyping ? "border-r-2 border-white animate-pulse" : ""}`}>
                {aiText}
              </p>
            </div>
          )}

          {/* Background Music */}
          {showMusic && (
            <div className="text-center mb-8">
              <h3 className="text-yellow-400 font-semibold mb-4 flex items-center justify-center gap-2">
                <span className="w-2 h-2 bg-yellow-400 rounded-full animate-pulse"></span>
                Trading Ambience
                <span className="w-2 h-2 bg-yellow-400 rounded-full animate-pulse"></span>
              </h3>
              <div className="inline-block p-4 bg-gray-900/50 backdrop-blur-sm border border-yellow-500/20 rounded-2xl">
                <iframe
                  width="300"
                  height="80"
                  src="https://www.youtube.com/embed/mwZfLjRM-qo?autoplay=1&loop=1&playlist=mwZfLjRM-qo"
                  frameBorder="0"
                  allow="autoplay; encrypted-media"
                  allowFullScreen
                  className="rounded-xl"
                />
              </div>
            </div>
          )}
        </div>

        {/* Trading Links */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6 w-full max-w-4xl">
          <a
            href="https://one.exnesstrack.org/a/ikaicwr27f"
            target="_blank"
            rel="noopener noreferrer"
            className="p-6 bg-gray-900/50 backdrop-blur-sm border border-yellow-500/20 rounded-2xl hover:border-yellow-500/40 transition-all duration-300 text-center group"
          >
            <div className="text-yellow-500 text-3xl mb-3">📊</div>
            <h3 className="text-white font-semibold mb-2">Trading Platform</h3>
            <p className="text-gray-400 text-sm">Akses Exness untuk trading real</p>
          </a>

          <Link
            href="/#kontak"
            className="p-6 bg-gray-900/50 backdrop-blur-sm border border-yellow-500/20 rounded-2xl hover:border-yellow-500/40 transition-all duration-300 text-center group"
          >
            <div className="text-yellow-500 text-3xl mb-3">💬</div>
            <h3 className="text-white font-semibold mb-2">Konsultasi</h3>
            <p className="text-gray-400 text-sm">Chat dengan mentor trading</p>
          </Link>

          <Link
            href="/dashboard"
            className="p-6 bg-gray-900/50 backdrop-blur-sm border border-yellow-500/20 rounded-2xl hover:border-yellow-500/40 transition-all duration-300 text-center group"
          >
            <div className="text-yellow-500 text-3xl mb-3">⚡</div>
            <h3 className="text-white font-semibold mb-2">Dashboard</h3>
            <p className="text-gray-400 text-sm">Panel trading profesional</p>
          </Link>
        </div>

        {/* Footer */}
        <div className="mt-16 text-center text-gray-500 text-sm">
          <p>Emika AI • Powered by Romsstrade Trading Intelligence</p>
          <p className="mt-2">Advanced Market Analysis • Professional Trading Solutions</p>
        </div>
      </div>
    </div>
  )
}
