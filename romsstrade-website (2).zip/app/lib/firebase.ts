import { initializeApp } from "firebase/app"
import { getAuth } from "firebase/auth"
import { getFirestore } from "firebase/firestore"

const firebaseConfig = {
  apiKey: "AIzaSyCgNnID2loaKWwIZLimgdLyE00O1lbblzk",
  authDomain: "romsstrade.firebaseapp.com",
  projectId: "romsstrade",
  storageBucket: "romsstrade.firebasestorage.app",
  messagingSenderId: "99931216193",
  appId: "1:99931216193:web:9566ea6e23423e741129c0",
  measurementId: "G-8XXHMRJMY4",
}

// Initialize Firebase
const app = initializeApp(firebaseConfig)

// Initialize Firebase Authentication and get a reference to the service
export const auth = getAuth(app)

// Initialize Cloud Firestore and get a reference to the service
export const db = getFirestore(app)

export default app
