"use client"
import { useState, useEffect } from "react"
import { Menu, TrendingUp, Shield, Clock, Users, ExternalLink, Sparkles } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import RomssTradeLogo from "../components/logo"

export default function HomePage() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isIndonesian, setIsIndonesian] = useState(true)

  // No need for particle effect logic anymore, as we're using a video background
  useEffect(() => {
    // Optional: If you want to ensure video plays on iOS, you might need to trigger play on user interaction
    // const videoElement = document.getElementById("background-video") as HTMLVideoElement;
    // if (videoElement) {
    //   videoElement.play().catch(error => console.log("Autoplay prevented:", error));
    // }
  }, [])

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen)
  }

  const switchLanguage = () => {
    setIsIndonesian(!isIndonesian)
  }

  const content = {
    id: {
      heroTitle: "Trading & Analisa",
      heroTitleSpan: "Profesional",
      heroDesc:
        "Bergabunglah dengan komunitas trader sukses kami. Dapatkan sinyal trading akurat, analisa mendalam, dan edukasi komprehensif untuk mengembangkan skill trading Anda dari pemula hingga expert.",
      platformTitle: "Platform Trading",
      platformTitleSpan: "Terpercaya",
      platformDesc:
        "Kami menggunakan dan merekomendasikan Exness sebagai broker trading terpercaya dengan kondisi terbaik di pasar.",
      platformFeatures: {
        traders: "1 juta+ trader aktif",
        licenses: "Lisensi regulasi lengkap",
        support: "Customer support 24/7",
        security: "Keamanan PCI DSS tersertifikasi",
      },
      platformButtons: {
        register: "Daftar Sekarang",
        demo: "Coba Demo Gratis",
      },
      contactTitle: "Hubungi",
      contactTitleSpan: "Tim Trading",
      contactDesc:
        "Kami siap membantu Anda memulai journey trading, memberikan sinyal harian, konsultasi strategi, dan edukasi trading yang terpercaya.",
      nav: {
        home: "Beranda",
        trading: "Trading",
        services: "Layanan",
        contact: "Kontak",
        ai: "Emika AI",
      },
      contacts: {
        telegram: {
          title: "Channel Trading",
          desc: "Gabung channel untuk sinyal trading harian dan analisa market terkini.",
          action: "Join Channel",
        },
        admin: {
          title: "Konsultasi Trading",
          desc: "Chat langsung dengan mentor untuk strategi personal dan analisa mendalam.",
          action: "Chat Mentor",
        },
        whatsapp: {
          title: "WhatsApp Trading",
          desc: "Konsultasi cepat seputar trading, sinyal, dan strategi via WhatsApp.",
          action: "Chat WhatsApp",
        },
        instagram: {
          title: "Trading Insights",
          desc: "Follow untuk tips trading harian, analisa market, dan edukasi visual.",
          action: "Follow Instagram",
        },
      },
    },
    en: {
      heroTitle: "Professional",
      heroTitleSpan: "Trading & Analysis",
      heroDesc:
        "Join our successful trader community. Get accurate trading signals, in-depth analysis, and comprehensive education to develop your trading skills from beginner to expert.",
      platformTitle: "Trusted Trading",
      platformTitleSpan: "Platform",
      platformDesc: "We use and recommend Exness as a trusted trading broker with the best market conditions.",
      platformFeatures: {
        traders: "1 million+ active traders",
        licenses: "Multiple regulatory licenses",
        support: "24/7 customer support",
        security: "PCI DSS certified security",
      },
      platformButtons: {
        register: "Register Now",
        demo: "Try Free Demo",
      },
      contactTitle: "Contact",
      contactTitleSpan: "Trading Team",
      contactDesc:
        "We're ready to help you start your trading journey, provide daily signals, strategy consultation, and trusted trading education.",
      nav: {
        home: "Home",
        trading: "Trading",
        services: "Services",
        contact: "Contact",
        ai: "Emika AI",
      },
      contacts: {
        telegram: {
          title: "Trading Channel",
          desc: "Join channel for daily trading signals and latest market analysis.",
          action: "Join Channel",
        },
        admin: {
          title: "Trading Consultation",
          desc: "Chat directly with mentors for personal strategy and in-depth analysis.",
          action: "Chat Mentor",
        },
        whatsapp: {
          title: "WhatsApp Trading",
          desc: "Quick consultation about trading, signals, and strategies via WhatsApp.",
          action: "Chat WhatsApp",
        },
        instagram: {
          title: "Trading Insights",
          desc: "Follow for daily trading tips, market analysis, and visual education.",
          action: "Follow Instagram",
        },
      },
    },
  }

  const currentContent = isIndonesian ? content.id : content.en

  return (
    <div className="min-h-screen bg-gray-800 text-white relative overflow-hidden">
      {/* Video Background */}
      <video
        id="background-video"
        className="fixed inset-0 w-full h-full object-cover z-0"
        autoPlay
        loop
        muted
        playsInline // Important for autoplay on mobile
        preload="auto"
      >
        <source src="https://files.catbox.moe/qz8vfu.mp4" type="video/mp4" />
        Your browser does not support the video tag.
      </video>

      {/* Dark Overlay for readability */}
      <div className="fixed inset-0 bg-gray-900 opacity-80 z-0 pointer-events-none"></div>

      {/* Header */}
      <header className="fixed w-full top-0 left-0 z-50 bg-gray-700/90 backdrop-blur-sm shadow-lg">
        <div className="flex justify-between items-center px-5 py-4">
          <RomssTradeLogo />

          <div className="flex items-center gap-3">
            <button
              onClick={switchLanguage}
              className="bg-gray-600 px-3 py-1 rounded-lg text-sm hover:bg-yellow-500 hover:text-gray-800 transition-colors"
            >
              {isIndonesian ? "🇮🇩 ID" : "🇬🇧 EN"}
            </button>

            <button className="md:hidden text-yellow-500 text-xl" onClick={toggleMenu}>
              <Menu size={24} />
            </button>
          </div>
        </div>

        {/* Navigation */}
        <nav
          className={`${isMenuOpen ? "flex" : "hidden"} md:flex flex-col md:flex-row justify-center gap-5 pb-3 md:pb-2`}
        >
          <a href="#" className="text-gray-300 hover:text-yellow-500 transition-colors font-medium">
            {currentContent.nav.home}
          </a>
          <a href="#platform" className="text-gray-300 hover:text-yellow-500 transition-colors font-medium">
            {currentContent.nav.trading}
          </a>
          <a href="#" className="text-gray-300 hover:text-yellow-500 transition-colors font-medium">
            {currentContent.nav.services}
          </a>
          <a href="#kontak" className="text-gray-300 hover:text-yellow-500 transition-colors font-medium">
            {currentContent.nav.contact}
          </a>
          <Link
            href="/emika"
            className="text-yellow-500 hover:text-yellow-400 transition-colors font-medium flex items-center gap-1"
          >
            <Sparkles size={16} />
            {currentContent.nav.ai}
          </Link>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="pt-36 pb-24 px-5 text-center relative z-10">
        <div className="animate-fade-in-up">
          <h1 className="text-4xl md:text-5xl font-black leading-tight mb-5">
            <span className="text-yellow-500 animate-glow">{currentContent.heroTitle}</span>{" "}
            {currentContent.heroTitleSpan}
          </h1>
          <p className="text-gray-300 max-w-2xl mx-auto text-base md:text-lg animate-fade-in-up animation-delay-300">
            {currentContent.heroDesc}
          </p>

          {/* New AI Feature Highlight */}
          <div className="mt-8 animate-fade-in-up animation-delay-500">
            <Link
              href="/emika"
              className="inline-flex items-center gap-3 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-6 py-3 rounded-xl font-semibold transition-all duration-300 transform hover:scale-105"
            >
              <Sparkles size={20} />
              <span>Coba Emika AI - Trading Intelligence</span>
              <span className="text-xs bg-white/20 px-2 py-1 rounded-full">NEW</span>
            </Link>
          </div>
        </div>
      </section>

      {/* Trading Platform Section */}
      <section id="platform" className="py-24 px-5 bg-gray-900/50 backdrop-blur-sm relative z-10">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16 animate-fade-in-up">
            <h2 className="text-3xl md:text-4xl font-bold mb-5">
              <span className="text-yellow-500">{currentContent.platformTitle}</span> {currentContent.platformTitleSpan}
            </h2>
            <p className="text-gray-300 max-w-2xl mx-auto">{currentContent.platformDesc}</p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Platform Image */}
            <div className="relative animate-fade-in-left">
              <div className="bg-gradient-to-br from-yellow-500/20 to-transparent p-8 rounded-2xl hover:scale-105 transition-transform duration-500">
                <Image
                  src="/images/exness-platform.png"
                  alt="Exness Trading Platform"
                  width={600}
                  height={400}
                  className="rounded-xl shadow-2xl"
                />
              </div>
            </div>

            {/* Platform Features */}
            <div className="space-y-8 animate-fade-in-right">
              <div className="text-center lg:text-left">
                <h3 className="text-2xl md:text-3xl font-bold mb-4">
                  Upgrade the way <span className="text-yellow-500">you trade</span>
                </h3>
                <p className="text-gray-300 mb-8">
                  Trade with the world's largest retail broker and benefit from better-than-market conditions.
                </p>
              </div>

              {/* Features Grid */}
              <div className="grid grid-cols-2 gap-6">
                <div className="flex items-center gap-3 hover:scale-105 transition-transform duration-300">
                  <Users className="text-yellow-500" size={24} />
                  <span className="text-sm">{currentContent.platformFeatures.traders}</span>
                </div>
                <div className="flex items-center gap-3 hover:scale-105 transition-transform duration-300">
                  <Shield className="text-yellow-500" size={24} />
                  <span className="text-sm">{currentContent.platformFeatures.licenses}</span>
                </div>
                <div className="flex items-center gap-3 hover:scale-105 transition-transform duration-300">
                  <Clock className="text-yellow-500" size={24} />
                  <span className="text-sm">{currentContent.platformFeatures.support}</span>
                </div>
                <div className="flex items-center gap-3 hover:scale-105 transition-transform duration-300">
                  <TrendingUp className="text-yellow-500" size={24} />
                  <span className="text-sm">{currentContent.platformFeatures.security}</span>
                </div>
              </div>

              {/* CTA Buttons */}
              <div className="flex flex-col sm:flex-row gap-4 pt-6">
                <a
                  href="https://one.exnesstrack.org/a/ikaicwr27f"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-yellow-500 text-black font-bold px-8 py-4 rounded-xl hover:bg-yellow-400 transition-all duration-300 hover:scale-105 flex items-center justify-center gap-2 animate-bounce-subtle"
                >
                  {currentContent.platformButtons.register}
                  <ExternalLink size={18} />
                </a>
                <a
                  href="https://one.exnesstrack.org/a/ikaicwr27f"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="border-2 border-yellow-500 text-yellow-500 font-bold px-8 py-4 rounded-xl hover:bg-yellow-500 hover:text-black transition-all duration-300 flex items-center justify-center gap-2"
                >
                  {currentContent.platformButtons.demo}
                  <ExternalLink size={18} />
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="kontak" className="py-24 px-5 bg-gray-700/50 backdrop-blur-sm text-center relative z-10">
        <h2 className="text-3xl md:text-4xl font-bold mb-5 animate-fade-in-up">
          {currentContent.contactTitle} <span className="text-yellow-500">{currentContent.contactTitleSpan}</span>
        </h2>
        <p className="text-gray-300 mb-12 max-w-2xl mx-auto animate-fade-in-up animation-delay-200">
          {currentContent.contactDesc}
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-6xl mx-auto">
          {/* Telegram Channel */}
          <div className="bg-gray-800/80 backdrop-blur-sm border border-gray-600 p-8 rounded-xl hover:transform hover:-translate-y-2 hover:shadow-lg hover:shadow-yellow-500/10 transition-all duration-300 animate-fade-in-up animation-delay-300">
            <div className="text-yellow-500 text-4xl mb-4 animate-bounce-subtle">
              <i className="fab fa-telegram"></i>
            </div>
            <h3 className="text-xl font-semibold mb-3">{currentContent.contacts.telegram.title}</h3>
            <p className="text-gray-400 text-sm mb-4">{currentContent.contacts.telegram.desc}</p>
            <a
              href="https://t.me/romstrader"
              className="text-yellow-500 font-bold hover:text-yellow-400 transition-colors"
              target="_blank"
              rel="noopener noreferrer"
            >
              {currentContent.contacts.telegram.action}
            </a>
          </div>

          {/* Admin Telegram */}
          <div className="bg-gray-800/80 backdrop-blur-sm border border-gray-600 p-8 rounded-xl hover:transform hover:-translate-y-2 hover:shadow-lg hover:shadow-yellow-500/10 transition-all duration-300 animate-fade-in-up animation-delay-400">
            <div className="text-yellow-500 text-4xl mb-4 animate-bounce-subtle">
              <i className="fab fa-telegram"></i>
            </div>
            <h3 className="text-xl font-semibold mb-3">{currentContent.contacts.admin.title}</h3>
            <p className="text-gray-400 text-sm mb-4">{currentContent.contacts.admin.desc}</p>
            <a
              href="https://t.me/Kyosih"
              className="text-yellow-500 font-bold hover:text-yellow-400 transition-colors"
              target="_blank"
              rel="noopener noreferrer"
            >
              {currentContent.contacts.admin.action}
            </a>
          </div>

          {/* WhatsApp */}
          <div className="bg-gray-800/80 backdrop-blur-sm border border-gray-600 p-8 rounded-xl hover:transform hover:-translate-y-2 hover:shadow-lg hover:shadow-yellow-500/10 transition-all duration-300 animate-fade-in-up animation-delay-500">
            <div className="text-yellow-500 text-4xl mb-4 animate-bounce-subtle">
              <i className="fab fa-whatsapp"></i>
            </div>
            <h3 className="text-xl font-semibold mb-3">{currentContent.contacts.whatsapp.title}</h3>
            <p className="text-gray-400 text-sm mb-4">{currentContent.contacts.whatsapp.desc}</p>
            <a
              href="https://wa.me/6287856077120"
              className="text-yellow-500 font-bold hover:text-yellow-400 transition-colors"
              target="_blank"
              rel="noopener noreferrer"
            >
              {currentContent.contacts.whatsapp.action}
            </a>
          </div>

          {/* Instagram */}
          <div className="bg-gray-800/80 backdrop-blur-sm border border-gray-600 p-8 rounded-xl hover:transform hover:-translate-y-2 hover:shadow-lg hover:shadow-yellow-500/10 transition-all duration-300 animate-fade-in-up animation-delay-600">
            <div className="text-yellow-500 text-4xl mb-4 animate-bounce-subtle">
              <i className="fab fa-instagram"></i>
            </div>
            <h3 className="text-xl font-semibold mb-3">{currentContent.contacts.instagram.title}</h3>
            <p className="text-gray-400 text-sm mb-4">{currentContent.contacts.instagram.desc}</p>
            <a
              href="https://instagram.com/_rommms"
              className="text-yellow-500 font-bold hover:text-yellow-400 transition-colors"
              target="_blank"
              rel="noopener noreferrer"
            >
              {currentContent.contacts.instagram.action}
            </a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900/80 backdrop-blur-sm text-center py-8 px-5 text-gray-500 text-sm relative z-10">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div>&copy; 2025 romsstrade. All rights reserved.</div>

            {/* Admin Login Link - External URL */}
            <div>
              <a
                href="https://login.romsstrade.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-600 hover:text-yellow-500 transition-colors text-xs font-mono tracking-wider animate-pulse"
              >
                romssadmin
              </a>
            </div>
          </div>
        </div>
      </footer>

      {/* Floating Customer Support */}
      <div className="fixed bottom-6 right-6 z-50 animate-bounce-subtle">
        <div className="group relative">
          {/* Support Avatar with Text - Both clickable */}
          <div
            className="bg-transparent cursor-pointer hover:scale-110 transition-all duration-300 hover:drop-shadow-lg flex flex-col items-center"
            onClick={() => {
              // Toggle menu visibility on click
              const menu = document.querySelector(".support-menu")
              if (menu) {
                menu.classList.toggle("opacity-0")
                menu.classList.toggle("opacity-100")
                menu.classList.toggle("translate-y-2")
                menu.classList.toggle("translate-y-0")
              }
            }}
          >
            <Image
              src="/images/support-avatar.png"
              alt="Customer Support"
              width={60}
              height={60}
              className="rounded-full animate-pulse"
            />
            {/* Support Text - Now clickable */}
            <div className="mt-2 bg-gray-800/90 backdrop-blur-sm px-3 py-1 rounded-full border border-gray-600 hover:bg-gray-700/90 transition-colors">
              <span className="text-yellow-500 text-xs font-semibold">Support</span>
            </div>
          </div>

          {/* Support Menu - appears on hover AND click */}
          <div className="support-menu absolute bottom-full right-0 mb-4 opacity-0 group-hover:opacity-100 transition-all duration-300 transform translate-y-2 group-hover:translate-y-0 pointer-events-none group-hover:pointer-events-auto">
            <div className="bg-gray-800/90 backdrop-blur-sm rounded-lg shadow-xl p-4 min-w-[200px] border border-gray-600">
              <h3 className="text-yellow-500 font-bold mb-3 text-sm">Customer Support</h3>
              <div className="space-y-2">
                <a
                  href="https://t.me/Kyosih"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 text-white hover:text-yellow-500 transition-colors text-sm p-2 hover:bg-gray-700 rounded"
                >
                  <i className="fab fa-telegram text-blue-400"></i>
                  <span>Telegram Support</span>
                </a>
                <a
                  href="https://wa.me/6287856077120"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 text-white hover:text-yellow-500 transition-colors text-sm p-2 hover:bg-gray-700 rounded"
                >
                  <i className="fab fa-whatsapp text-green-400"></i>
                  <span>WhatsApp Support</span>
                </a>
                <Link
                  href="/emika"
                  className="flex items-center gap-2 text-white hover:text-yellow-500 transition-colors text-sm p-2 hover:bg-gray-700 rounded"
                >
                  <Sparkles size={16} className="text-purple-400" />
                  <span>Emika AI</span>
                </Link>
                <a
                  href="#kontak"
                  className="flex items-center gap-2 text-white hover:text-yellow-500 transition-colors text-sm p-2 hover:bg-gray-700 rounded"
                >
                  <i className="fas fa-envelope text-gray-400"></i>
                  <span>Contact Form</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
