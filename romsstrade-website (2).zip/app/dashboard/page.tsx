"use client"

import { useState, useEffect } from "react"
import { signOut, type User } from "firebase/auth"
import { auth } from "../lib/firebase"
import AuthGuard from "../../components/auth-guard"
import RomssTradeLogo from "../../components/logo"
import { LogOut, UserIcon, TrendingUp, DollarSign, BarChart3 } from "lucide-react"

export default function DashboardPage() {
  const [user, setUser] = useState<User | null>(null)

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((user) => {
      setUser(user)
    })

    return () => unsubscribe()
  }, [])

  const handleLogout = async () => {
    try {
      await signOut(auth)
      window.location.href = "/"
    } catch (error) {
      console.error("Error signing out:", error)
    }
  }

  return (
    <AuthGuard>
      <div className="min-h-screen bg-gray-800">
        {/* Header */}
        <header className="bg-gray-900 border-b border-gray-700 px-6 py-4">
          <div className="flex items-center justify-between">
            <RomssTradeLogo />

            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 text-white">
                <UserIcon size={20} />
                <span className="hidden sm:inline">{user?.displayName || user?.email}</span>
              </div>

              <button
                onClick={handleLogout}
                className="flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg transition-colors"
              >
                <LogOut size={16} />
                <span className="hidden sm:inline">Logout</span>
              </button>
            </div>
          </div>
        </header>

        {/* Dashboard Content */}
        <main className="p-6">
          <div className="max-w-7xl mx-auto">
            {/* Welcome Section */}
            <div className="mb-8">
              <h1 className="text-3xl font-bold text-white mb-2">
                Selamat Datang, {user?.displayName || "Trader"}! 👋
              </h1>
              <p className="text-gray-400">Dashboard trading profesional Anda siap digunakan</p>
            </div>

            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <div className="bg-gray-900 border border-gray-700 rounded-xl p-6">
                <div className="flex items-center gap-4">
                  <div className="bg-yellow-500/20 p-3 rounded-lg">
                    <TrendingUp className="text-yellow-500" size={24} />
                  </div>
                  <div>
                    <h3 className="text-white font-semibold">Total Profit</h3>
                    <p className="text-2xl font-bold text-green-400">+$2,450</p>
                  </div>
                </div>
              </div>

              <div className="bg-gray-900 border border-gray-700 rounded-xl p-6">
                <div className="flex items-center gap-4">
                  <div className="bg-blue-500/20 p-3 rounded-lg">
                    <DollarSign className="text-blue-400" size={24} />
                  </div>
                  <div>
                    <h3 className="text-white font-semibold">Balance</h3>
                    <p className="text-2xl font-bold text-white">$15,750</p>
                  </div>
                </div>
              </div>

              <div className="bg-gray-900 border border-gray-700 rounded-xl p-6">
                <div className="flex items-center gap-4">
                  <div className="bg-purple-500/20 p-3 rounded-lg">
                    <BarChart3 className="text-purple-400" size={24} />
                  </div>
                  <div>
                    <h3 className="text-white font-semibold">Win Rate</h3>
                    <p className="text-2xl font-bold text-yellow-500">78.5%</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Trading Platform Access */}
              <div className="bg-gray-900 border border-gray-700 rounded-xl p-6">
                <h2 className="text-xl font-bold text-white mb-4">Platform Trading</h2>
                <p className="text-gray-400 mb-6">Akses langsung ke platform Exness untuk mulai trading</p>
                <a
                  href="https://one.exnesstrack.org/a/ikaicwr27f"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-yellow-500 text-black font-bold px-6 py-3 rounded-xl hover:bg-yellow-400 transition-colors inline-flex items-center gap-2"
                >
                  Buka Platform
                  <TrendingUp size={18} />
                </a>
              </div>

              {/* Account Info */}
              <div className="bg-gray-900 border border-gray-700 rounded-xl p-6">
                <h2 className="text-xl font-bold text-white mb-4">Informasi Akun</h2>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Email:</span>
                    <span className="text-white">{user?.email}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Status:</span>
                    <span className="text-green-400">Verified</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Member Since:</span>
                    <span className="text-white">
                      {user?.metadata.creationTime
                        ? new Date(user.metadata.creationTime).toLocaleDateString("id-ID")
                        : "N/A"}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </AuthGuard>
  )
}
